import React, { useEffect, useState } from "react";
import axios from "axios";
import "./pokedex.css"; 
import "bootstrap/dist/css/bootstrap.min.css"; 

interface Pokemon {
    name: string;
    url: string;
}

const Pokedex = () => {
    const [data, setData] = useState<Pokemon[]>([]);
    const [generation, setGeneration] = useState(0);
    const [offset, setOffset] = useState(0);
    const [limit, setLimit] = useState(151);

    const generations = [
        { offset: 0, limit: 151, name: "Primera" },
        { offset: 151, limit: 100, name: "Segunda" },
        { offset: 251, limit: 135, name: "Tercera" },
        { offset: 386, limit: 107, name: "Cuarta" },
        { offset: 493, limit: 156, name: "Quinta" },
    ];

    const obtenerPokemons = async (offset: number, limit: number) => {
        try {
            const response = await axios.get(`https://pokeapi.co/api/v2/pokemon?offset=${offset}&limit=${limit}`);
            const json = response.data.results;
            setData(json);
        } catch (error) {
            console.error(error);
        }
    };

    useEffect(() => {
        obtenerPokemons(offset, limit);
    }, [offset, limit]);

    const handleGenerationChange = (index: number) => {
        setGeneration(index);
        setOffset(generations[index].offset);
        setLimit(generations[index].limit);
    };

    return (
        <div className="container">
            <h1 className="text-center my-4">Pokédex</h1>
            <div className="btn-group mb-4" role="group" aria-label="Generations">
                {generations.map((gen, index) => (
                    <button
                        key={index}
                        type="button"
                        className={`btn btn-primary ${generation === index ? 'active' : ''}`}
                        onClick={() => handleGenerationChange(index)}
                    >
                        {gen.name}
                    </button>
                ))}
            </div>
            <div className="table-responsive">
                <table className="table table-striped">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Nombre</th>
                            <th>poke-img</th>
                        </tr>
                    </thead>
                    <tbody>
                        {data.map((item) => {
                            const ruta = item.url;
                            const pock = ruta.split('/');
                            const id = pock[6];
                            const urlP = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${id}.png`;

                            return (
                                <tr key={id}>
                                    <td>{id}</td>
                                    <td>{item.name}</td>
                                    <td><img src={urlP} width="45" height="45" alt={`Sprite de ${item.name}`} /></td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default Pokedex;
